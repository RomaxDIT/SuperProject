package com.company;

public class User
{
    private String name;
    private String password;
}
